Description: Painkiller: Overdose VR is an enhanced version of the original Painkiller VR mod that allows you to play Painkiller: Overdose in VR.

Information:
1) The first time you launch the mod, it may take some time to prepare certain game files for proper VR operation. Launching can take anywhere from 30 seconds to 5 minutes. Subsequent launches will be very fast.
2) When launching the modification, the game will delete the LScripts and Textures folders from the Data folder, if they exist. This is required for the modification to function correctly.
2) The modification does not replace any files in the game; when running Bin/Overdose.exe, the game will run unchanged.
3) To remove the modification, delete the executable file Painkiller - Overdose VR v.1.1.exe.

Installation:
1) This modification is intended exclusively for Painkiller: Overdose and is not compatible with other modifications.
2) Copy the Painkiller - Overdose VR v.1.1.exe executable file to the game's root folder (the key Bin and Data folders should be there).
3) Launch Painkiller - Overdose VR v.1.1.exe with the VR headset connected.

Recommendations:
1) This mod has only been tested on Oculus Quest 2, Oculus Quest 3, but it is expected to work on other devices as well.
2) To launch the game, you must connect to your computer via Virtual Desktop, Steam Link or Meta Horizon Link.
3) If the game doesn't launch via Meta Horizon Link, the game has stopped working on the latest version of the PC app. You will need to install the older version, which you can download from this link: https://disk.yandex.ru/d/uxm1X429PJALag
You need to copy the Support folder to the C:\Program Files\Meta Horizon\ folder, but first delete the Support folder from there.

Social Networks:
1) Painkiller Club Discord: https://discord.gg/cQXyuZEkHC
2) Painkiller Club VK: https://vk.ru/painkillerclub
3) STR_Paragor's Content Development: https://vk.ru/str_paragor
4) Painkiller Russian Community: https://www.moddb.com/company/painkiller-russian-community

Authors:
1) Alexey "STR_Paragor" Belov - Painkiller - Overdose VR, programming, animation, art
2) Sergey "BlooDFloweR" Lubimov - Painkiller - Overdose VR, programming, art
3) Alexey "Astaroth" Mironov - Painkiller - Overdose VR, programming

Special thanks to:
1) Alexey "Fluorescent Hallucinogen" Rodionov for releasing the VR mod for Painkiller.
The mod was taken and adapted from this link: https://github.com/FluorescentHallucinogen/painkiller-vr-mod. The VR mod version is 0.1.9.

Enjoy the game!